package BlackJavaGame.com;

public class Main {

    public static void main(String[] args) {
        Game CardGame = new Game();
        CardGame.playGame();
    }

}
