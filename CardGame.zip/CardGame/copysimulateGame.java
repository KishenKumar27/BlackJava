//package com.jetbrain.CardGame;
//
//import java.util.ArrayList;
//import java.util.Random;
//import java.util.Scanner;
//
//public class copysimulateGame {
//}
//
//
//package com.jetbrain.CardGame;
//
//        import java.util.*; // Import Random
//
//public class SimulateGame {
//    // Attributes
//
//    //    private static Player playerOne = new Player("Bob");
////    private static Player playerTwo = new Player("Alice");
////    private static Player playerThree = new Player("Ernesto");
////    private static Player currentPlayer = playerOne;
//    private static Deck deck = new Deck(true); // Shuffle deck automatically
//    private static ArrayList<Card> table = new ArrayList<>();
//    private static Card topCard;
//    private static int roundsPlayed = 1;
//    private static boolean gameOver = false;
//
//    // Main method
//
//    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter player 1 name: ");
//        String p1 = input.nextLine();
//
//        System.out.println("Enter player 2 name: ");
//        String p2 = input.nextLine();
//
//        System.out.println("Enter player 3 name: ");
//        String p3 = input.nextLine();
//
//        Player playerOne = new Player(p1);
//        Player playerTwo = new Player(p2);
//        Player playerThree = new Player(p3);
//        Player currentPlayer = playerOne;
//
//        playGame(playerOne, playerTwo, playerThree,  currentPlayer);
//    }
//
//    // Methods
//
//    // Play the simple card game
//    public static void playGame(Player playerOne,Player playerTwo,Player playerThree,Player currentPlayer) {
//        System.out.println("Starting simple card game simulation...");
//        System.out.println();
//
//        dealCards(playerOne, playerTwo, playerThree); // Deal 26 cards to each player
//        chooseFirstPlayer( playerOne, playerTwo, playerThree); // Choose who goes first
//        playRounds(  playerOne,  playerTwo,  playerThree, currentPlayer); // Start the rounds
//        declareWinner( playerOne, playerTwo, playerThree); // Declare a winner
//    }
//
//    // Deal 26 cards to each hand in alternating order
//    public static void dealCards(Player playerOne,Player playerTwo,Player playerThree) {
//        for (int i = 0; i < 17; i++) {
//            playerOne.takeCard(deck.deal());
//            playerTwo.takeCard(deck.deal());
//            playerThree.takeCard(deck.deal());
//        }
//    }
//
//    // Choose who goes first
//    public static void chooseFirstPlayer(Player playerOne,Player playerTwo,Player playerThree) {
//        Random random = new Random();
//        int n = random.nextInt(3);
//
//        if (n == 1) { // Make playerTwo the new playerOne
//            Player temp = playerOne;
//            playerOne = playerTwo;
//            playerTwo = temp;
//        }
//        else if (n == 2){ // Make playerThree the new playerOne
//            Player temp = playerTwo;
//            playerTwo = playerThree;
//            playerThree = temp;
//        }
//    }
//
//    // Play rounds, max 10
//    public static void playRounds(Player playerOne,Player playerTwo,Player playerThree,Player currentPlayer) {
//        while (roundsPlayed <= 3 && (gameOver == false)) {
//            // Display the round number
//            System.out.println("ROUND " + roundsPlayed);
//            System.out.println();
//
//            // Display each player's hand
//            displayHands(  playerOne,  playerTwo,  playerThree);
//
//            // Play individual round
//            playRound(  playerOne,  playerTwo,  playerThree,  currentPlayer);
//
//            // Increment roundsPlayed counter
//            roundsPlayed++;
//        }
//    }
//
//    // Play an individual round
//    public static void playRound(Player playerOne,Player playerTwo,Player playerThree,Player currentPlayer) {
//        boolean suitMatch = false; // Flag for notifying a suit match
//        Card cardToPlay;
//
//        if ((playerOne.handSize() == 52) || (playerTwo.handSize() == 52) ||  (playerThree.handSize() == 52)) {
//            gameOver = true;
//        }
//
//        while (suitMatch == false) {
//            // Current player places card on table
//            cardToPlay = currentPlayer.playCard();
//            table.add(cardToPlay);
//
//            // Check if there's a suit match
//            suitMatch = checkSuitMatch( currentPlayer);
//
//            if (suitMatch == false)
//                switchCurrentPlayer(  playerOne,  playerTwo,  playerThree, currentPlayer);
//        }
//
//        collectCards(  currentPlayer);
//        System.out.println();
//
//        // Sleep for a second before beginning a new round
//        try {
//            Thread.sleep(500);
//        }
//        catch (InterruptedException e) {
//        }
//    }
//
//    // Switch current player
//    public static void switchCurrentPlayer(Player playerOne,Player playerTwo,Player playerThree,Player currentPlayer) {
//        if (currentPlayer == playerOne)
//            currentPlayer = playerTwo;
//        else if (currentPlayer == playerTwo)
//            currentPlayer = playerOne;
//        else if (currentPlayer == playerThree)
//            currentPlayer = playerOne;
//    }
//
//    // Check for a suit match
//    public static boolean checkSuitMatch( Player currentPlayer) {
//        int tableSize = table.size();
//        int lastSuit;
//        int topSuit;
//
//        if (tableSize < 2) {
//            return false;
//        }
//        else {
//            lastSuit = table.get(tableSize - 1).getSuit();
//            topSuit = table.get(tableSize - 2).getSuit();
//        }
//
//        // Check suit equivalence
//        if (lastSuit == topSuit) {
//            System.out.println();
//            System.out.println(currentPlayer.getName() + " wins the round!");
//            System.out.println();
//
//            return true;
//        }
//
//        return false;
//    }
//
//    // Collect cards from table
//    public static void collectCards( Player currentPlayer) {
//        // Print a message
//        System.out.print(currentPlayer.getName() + " takes the table (" +
//                table.size() + "): ");
//        displayTable();
//
//        // Player takes each card from the table and adds to hand
//        for (int i = 0; i < table.size(); i++) {
//            Card cardToTake = table.get(i);
//            currentPlayer.takeCard(cardToTake);
//        }
//
//        table.clear();
//    }
//
//    // Displays all the cards currently on the table
//    public static void displayTable() {
//        for (int i = 0; i < table.size(); i++) {
//            if (table.get(i) != null) {
//                System.out.print(table.get(i).getName() + " ");
//            }
//        }
//
//        System.out.println();
//        System.out.println();
//    }
//
//    // Displays each player's current hand
//    public static void displayHands(Player playerOne,Player playerTwo,Player playerThree) {
//        playerOne.displayHand();
//        playerTwo.displayHand();
//        playerThree.displayHand();
//    }
//
//    // Declare a winner
//    public static void declareWinner(Player playerOne,Player playerTwo,Player playerThree) {
//        if (playerOne.handSize() > playerTwo.handSize()) {
//            System.out.println(playerOne.getName().toUpperCase() + " WINS " +
//                    "WITH A TOTAL OF " + playerOne.handSize() + " CARDS!");
//        }
//        else if (playerTwo.handSize() > playerOne.handSize()) {
//            System.out.println(playerTwo.getName().toUpperCase() + " WINS " +
//                    "WITH A TOTAL OF " + playerTwo.handSize() + " CARDS!");
//        }
//        else if (playerThree.handSize() > playerTwo.handSize()) {
//            System.out.println(playerThree.getName().toUpperCase() + " WINS " +
//                    "WITH A TOTAL OF " + playerThree.handSize() + " CARDS!");
//        }
//        else {
//            System.out.println("TIE! WOW IT'S SUPER RARE!");
//        }
//
//        System.out.println();
//    }
//
