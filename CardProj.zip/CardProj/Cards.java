package CardProj;

import java.util.ArrayList;
import java.util.List;

public class Cards {

	
	private Character [] Suit = {'d','c','h','s'};
	private Character [] Faces = {'5','6','7','8','9','A','2','3','4','X','J','Q','K'};
	
	public Cards() {
		
	}

	
	public Character[] getFace() {
		return Faces;
	}
	public Character[] getSuits() {
		return Suit;
	}
	
	public void setSuits(Character[] suits) {
		Suit = suits;
	}
	
	public void setFace(Character[] face) {
		Faces = face;
	}
	
}
